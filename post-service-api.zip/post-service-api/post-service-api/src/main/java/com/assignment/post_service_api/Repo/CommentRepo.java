package com.assignment.post_service_api.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.assignment.post_service_api.entity.Comment;

public interface CommentRepo extends JpaRepository<Comment, Long> {
}