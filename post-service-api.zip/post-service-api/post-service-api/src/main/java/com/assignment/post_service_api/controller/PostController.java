package com.assignment.post_service_api.controller;



import org.jspecify.annotations.Nullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.assignment.post_service_api.Dto.CreatePostRequest;
import com.assignment.post_service_api.entity.Post;
import com.assignment.post_service_api.service.PostService;


@RestController
@RequestMapping("/api/posts")
public class PostController {

    @Autowired
    private PostService postService;

    
    
    @PostMapping
    public ResponseEntity<Post> createPost(@RequestBody CreatePostRequest request) {
        return new ResponseEntity<>(postService.createPost(request), HttpStatus.CREATED);
    }

   
    @PostMapping("/{postId}/like")
    public ResponseEntity<String> likePost(@PathVariable Long postId) {
        postService.likePost(postId);
        return ResponseEntity.ok("Post liked successfully");
    }

    
    @GetMapping
    public ResponseEntity<@Nullable Object> getAllPosts() {
        return ResponseEntity.ok(postService.getAllPosts());
    }

    
    @GetMapping("/{postId}")
    public ResponseEntity<@Nullable Object> getPostById(@PathVariable Long postId) {
        return ResponseEntity.ok(postService.getPostById(postId));
    }
}