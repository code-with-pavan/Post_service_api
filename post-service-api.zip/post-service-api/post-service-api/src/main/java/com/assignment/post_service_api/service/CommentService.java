package com.assignment.post_service_api.service;

import java.time.LocalDateTime;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.post_service_api.Dao.CommentDao;
import com.assignment.post_service_api.Dto.CreateCommentRequest;
import com.assignment.post_service_api.Repo.PostRepo;
import com.assignment.post_service_api.entity.Comment;

import jakarta.transaction.Transactional;


@Service
public class CommentService {

    @Autowired
    private CommentDao commentDao;

    @Autowired
    PostRepo postRepo;
    	
    @Transactional
    
    public Comment addComment(Long postId, CreateCommentRequest request) {

      
        postRepo.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post not found"));

        Comment comment = new Comment();
        comment.setPostId(postId);
        comment.setAuthorId(request.getAuthorId());
        comment.setAuthorType(request.getAuthorType());
        comment.setContent(request.getContent());
        comment.setDepthLevel(request.getDepthLevel());
        comment.setCreatedAt(LocalDateTime.now());

        return commentDao.save(comment);
    }

    
    public List<Comment> getCommentsByPostId(Long postId) {

        postRepo.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post not found"));

        return commentDao.findByPostId(postId);
    }
	}
