package com.assignment.post_service_api.Dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.assignment.post_service_api.entity.Post;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Repository
public class PostDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    public Post save(Post post) {
        entityManager.persist(post);
        return post;
    }

   
    public Post findById(Long id) {
        return entityManager.find(Post.class, id);
    }

    
    public List<Post> findAll() {
        return entityManager
                .createQuery("FROM Post", Post.class)
                .getResultList();
    }
}