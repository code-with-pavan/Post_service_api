package com.assignment.post_service_api.service;

import java.time.LocalDateTime;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.post_service_api.Dao.PostDao;
import com.assignment.post_service_api.Dto.CreatePostRequest;
import com.assignment.post_service_api.entity.Post;

import jakarta.transaction.Transactional;


@Service
public class PostService {

    @Autowired
    private PostDao postDao;
    
   
    @Transactional
    public Post createPost(CreatePostRequest request) {

        Post post = new Post();
        post.setAuthorId(request.getAuthorId());
        post.setAuthorType(request.getAuthorType());
        post.setContent(request.getContent());
        post.setCreatedAt(LocalDateTime.now());

        return postDao.save(post);
    }

   
    public void likePost(Long postId) {
        Post post = postDao.findById(postId);
        if (post == null) {
            throw new RuntimeException("Post not found");
        }
    }

    
    public List<Post> getAllPosts() {
        return postDao.findAll();
    }

    public Post getPostById(Long postId) {
        Post post = postDao.findById(postId);
        if (post == null) {
            throw new RuntimeException("Post not found");
        }
        return post;
    }
}
