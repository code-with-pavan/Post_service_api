package com.assignment.post_service_api.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.assignment.post_service_api.entity.Bot;

public interface BotRepo extends JpaRepository<Bot, Long>
{

}
