package com.assignment.post_service_api.Dto;

public class CreateCommentRequest {
	
	
private Long authorId;
private String authorType; 
private String content;
private int depthLevel;



public Long getAuthorId() {
    return authorId;
}

public void setAuthorId(Long authorId) {
    this.authorId = authorId;
}

public String getAuthorType() {
    return authorType;
}

public void setAuthorType(String authorType) {
    this.authorType = authorType;
}

public String getContent() {
    return content;
}

public void setContent(String content) {
    this.content = content;
}

public int getDepthLevel() {
    return depthLevel;
}

public void setDepthLevel(int depthLevel) {
    this.depthLevel = depthLevel;
}


}
