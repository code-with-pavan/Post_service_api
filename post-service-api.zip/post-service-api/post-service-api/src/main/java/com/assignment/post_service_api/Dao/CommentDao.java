package com.assignment.post_service_api.Dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.assignment.post_service_api.entity.Comment;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;


@Repository
public class CommentDao {

    @PersistenceContext
    private EntityManager entityManager;

    
    public Comment save(Comment comment) {
        entityManager.persist(comment);
        return comment;
    }

    
    public List<Comment> findByPostId(Long postId) {
        return entityManager
                .createQuery("FROM Comment c WHERE c.postId = :postId", Comment.class)
                .setParameter("postId", postId)
                .getResultList();
    }
}