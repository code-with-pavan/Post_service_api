package com.assignment.post_service_api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.assignment.post_service_api.Dto.CreateCommentRequest;
import com.assignment.post_service_api.entity.Comment;
import com.assignment.post_service_api.service.CommentService;



@RestController
@RequestMapping("/api/posts")
public class CommentController {
	
	    @Autowired
	    private CommentService commentService;

	 
	    @PostMapping("/{postId}/comments")
	    public ResponseEntity<Comment> addComment(
	            @PathVariable Long postId,
	            @RequestBody CreateCommentRequest request) {

	        return new ResponseEntity<>(
	                commentService.addComment(postId, request),
	                HttpStatus.CREATED
	        );
	    }

	
	    @GetMapping("/{postId}/comments")
	    public ResponseEntity<List<Comment>> getComments(@PathVariable Long postId) {
	        return ResponseEntity.ok(
	                commentService.getCommentsByPostId(postId)
	        );
	    }
	}
